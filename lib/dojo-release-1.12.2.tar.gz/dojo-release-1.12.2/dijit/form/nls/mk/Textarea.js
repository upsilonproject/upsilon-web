//>>built
define("dijit/form/nls/mk/Textarea",{iframeEditTitle:"\u0443\u0440\u0435\u0434\u0438 \u043e\u0431\u043b\u0430\u0441\u0442",iframeFocusTitle:"\u0443\u0440\u0435\u0434\u0438 \u0440\u0430\u043c\u043a\u0430 \u043d\u0430 \u043e\u0431\u043b\u0430\u0441\u0442"});
//# sourceMappingURL=Textarea.js.map