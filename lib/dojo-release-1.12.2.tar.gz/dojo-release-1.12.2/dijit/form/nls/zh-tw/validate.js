//>>built
define("dijit/form/nls/zh-tw/validate",{invalidMessage:"\u8f38\u5165\u7684\u503c\u7121\u6548\u3002",missingMessage:"\u5fc5\u9808\u63d0\u4f9b\u6b64\u503c\u3002",rangeMessage:"\u6b64\u503c\u8d85\u51fa\u7bc4\u570d\u3002"});
//# sourceMappingURL=validate.js.map