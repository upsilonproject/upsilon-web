//>>built
define("dijit/form/nls/cs/Textarea",{iframeEditTitle:"oblast \u00faprav",iframeFocusTitle:"r\u00e1mec oblasti \u00faprav"});
//# sourceMappingURL=Textarea.js.map