//>>built
define("dijit/form/nls/sv/ComboBox",{previousMessage:"Tidigare val",nextMessage:"Fler val"});
//# sourceMappingURL=ComboBox.js.map