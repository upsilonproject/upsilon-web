//>>built
define("dijit/form/nls/pl/validate",{invalidMessage:"Wprowadzona warto\u015b\u0107 jest nieprawid\u0142owa.",missingMessage:"Ta warto\u015b\u0107 jest wymagana.",rangeMessage:"Ta warto\u015b\u0107 jest spoza zakresu."});
//# sourceMappingURL=validate.js.map