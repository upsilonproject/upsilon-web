//>>built
define("dijit/form/nls/bs/Textarea",{iframeEditTitle:"podru\u010dje ure\u0111ivanja",iframeFocusTitle:"okvir podru\u010dja ure\u0111ivanja"});
//# sourceMappingURL=Textarea.js.map