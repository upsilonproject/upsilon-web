//>>built
define("dijit/form/nls/ar/Textarea",{iframeEditTitle:"\u0645\u0633\u0627\u062d\u0629 \u0627\u0644\u062a\u062d\u0631\u064a\u0631",iframeFocusTitle:"\u0627\u0637\u0627\u0631 \u0645\u0633\u0627\u062d\u0629 \u0627\u0644\u062a\u062d\u0631\u064a\u0631"});
//# sourceMappingURL=Textarea.js.map