//>>built
define("dijit/form/nls/hu/validate",{invalidMessage:"A megadott \u00e9rt\u00e9k \u00e9rv\u00e9nytelen.",missingMessage:"Meg kell adni egy \u00e9rt\u00e9ket.",rangeMessage:"Az \u00e9rt\u00e9k k\u00edv\u00fcl van a megengedett tartom\u00e1nyon."});
//# sourceMappingURL=validate.js.map