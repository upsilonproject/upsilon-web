<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
    <head>
    <title>Dojo CORE and BASE D.O.H. Unit Test Runner</title>
    <meta http-equiv="REFRESH" content="0;url=../../../util/doh/runner.html?test=util/docscripts/tests/basic"></HEAD>
    <BODY>
        Redirecting to D.O.H runner.
    </BODY>
</HTML> 
