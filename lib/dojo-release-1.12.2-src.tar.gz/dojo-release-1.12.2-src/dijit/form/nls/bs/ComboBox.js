define({      
//begin v1.x content
		previousMessage: "Prethodni izbori",
		nextMessage: "Još izbora"
//end v1.x content
});

