define(
({
		previousMessage: "Forrige valg",
		nextMessage: "Flere valg"
})
);
